
function atual(){
    document.getElementById('DataHora').innerHTML= Date()
}